﻿Public Class login

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()

    End Sub

    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox1.KeyPress
        TextBox1.MaxLength = 20
        If e.KeyChar = Chr(13) Then
            TextBox2.Focus()
        End If

    End Sub

    Private Sub TextBox2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox2.KeyPress
        TextBox2.MaxLength = 12
        If e.KeyChar = Chr(13) Then
            Button1.Focus()
        End If

    End Sub

    Private Sub PictureBox3_MouseDown(sender As Object, e As MouseEventArgs) Handles PictureBox3.MouseDown
        TextBox2.UseSystemPasswordChar = False
    End Sub

    Private Sub PictureBox3_MouseUp(sender As Object, e As MouseEventArgs) Handles PictureBox3.MouseUp
        TextBox2.UseSystemPasswordChar = True
    End Sub
    Dim hitung As String
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'Jika data tidak di isi
        If TextBox1.Text = "" Or TextBox2.Text = "" Then
            MsgBox("Mohon Isi Data Dengan Benar ...", MsgBoxStyle.Critical, "Peringatan!!!")
            TextBox1.Clear()
            TextBox2.Clear()
            TextBox1.Focus()
        Else
            'Jika Username/Password Benar
            If TextBox1.Text = "andra" And TextBox2.Text = "222" Then
                MsgBox("Login Berhasil ...", MsgBoxStyle.Information, "Informasi")
                MenuUtama.Show()
                Me.Hide() 'Jika menggunakan me.close maka program akan close
                'Jika username/password tidak sesuai
            ElseIf TextBox1.Text <> "andra" And TextBox2.Text <> "123" Then
                MsgBox("Username atau Password Salah ...", MsgBoxStyle.Information, "Informasi")
                TextBox1.Clear()
                TextBox2.Clear()
                TextBox1.Focus()
                'Gagal Login 3x
                hitung = hitung + 1
                If hitung > 2 Then
                    MsgBox("ANDA SUDAH GAGAL LOGIN SEBANYAK 3x, KOMPUTER INI AKAN KAMI MUSNAHKAN ...", MsgBoxStyle.Critical, "DANGER!!!")
                    End
                End If
                Exit Sub

            End If
        End If
    End Sub

    Private Sub login_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class