﻿Imports System.Data.Odbc

Public Class FormUser
    Dim pathFoto As String = ""
    Dim folderFoto As String = ""

    Sub tampilData()
        Try
            koneksi()
            Dim query As String = "SELECT * FROM tbl_user"
            da = New OdbcDataAdapter(query, conn)
            ds = New DataSet
            da.Fill(ds, "tbl_user")
            dgvUser.DataSource = ds.Tables("tbl_user")
        Catch ex As Exception
            MsgBox("Gagal Tampil: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub

    Sub isiUsername()
        Try
            koneksi()
            Dim query As String = "SELECT username FROM tbl_user"
            cmd = New OdbcCommand(query, conn)
            rd = cmd.ExecuteReader()
            cmbUsername.Items.Clear()
            While rd.Read()
                cmbUsername.Items.Add(rd("username").ToString)
            End While
        Catch ex As Exception
            MsgBox("Gagal Load Username: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub

    Sub clearForm()
        cmbUsername.Text = ""
        txtPassword.Clear()
        cmbStatus.SelectedIndex = -1
        pbFoto.Image = Nothing
        pathFoto = ""
    End Sub

    Private Sub btnSimpan_Click(sender As Object, e As EventArgs) Handles btnSimpan.Click
        If cmbUsername.Text = "" Or txtPassword.Text = "" Or cmbStatus.SelectedIndex = -1 Or pathFoto = "" Or txtLokasiFoto.Text = "" Then
            MsgBox("Data belum lengkap")
            Exit Sub
        End If

        ' Ambil nama file saja
        Dim namaFileFoto As String = System.IO.Path.GetFileName(pathFoto)
        Dim fullPathFotoDB As String = System.IO.Path.Combine(txtLokasiFoto.Text, namaFileFoto)

        Try
            koneksi()
            Dim cekQuery As String = "SELECT COUNT(*) FROM tbl_user WHERE username = ?"
            cmd = New OdbcCommand(cekQuery, conn)
            cmd.Parameters.AddWithValue("@1", cmbUsername.Text)
            Dim ada As Integer = cmd.ExecuteScalar()

            If ada > 0 Then
                ' Update
                Dim updateQuery As String = "UPDATE tbl_user SET password = ?, status_user = ?, foto_user = ? WHERE username = ?"
                cmd = New OdbcCommand(updateQuery, conn)
                cmd.Parameters.AddWithValue("@1", txtPassword.Text)
                cmd.Parameters.AddWithValue("@2", cmbStatus.Text)
                cmd.Parameters.AddWithValue("@3", fullPathFotoDB)
                cmd.Parameters.AddWithValue("@4", cmbUsername.Text)
                cmd.ExecuteNonQuery()
                MsgBox("Data User Diperbarui")
            Else
                ' Insert
                Dim insertQuery As String = "INSERT INTO tbl_user (username, password, status_user, foto_user) VALUES (?, ?, ?, ?)"
                cmd = New OdbcCommand(insertQuery, conn)
                cmd.Parameters.AddWithValue("@1", cmbUsername.Text)
                cmd.Parameters.AddWithValue("@2", txtPassword.Text)
                cmd.Parameters.AddWithValue("@3", cmbStatus.Text)
                cmd.Parameters.AddWithValue("@4", fullPathFotoDB)
                cmd.ExecuteNonQuery()
                MsgBox("Data User Ditambahkan")
            End If

            tampilData()
            isiUsername()
            clearForm()
        Catch ex As Exception
            MsgBox("Gagal Simpan: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub

    Private Sub btnPilihFoto_Click(sender As Object, e As EventArgs) Handles btnPilihFoto.Click
        OpenFileDialog1.Filter = "Gambar|*.jpg;*.jpeg;*.png;*.bmp"
        If OpenFileDialog1.ShowDialog = DialogResult.OK Then
            pathFoto = OpenFileDialog1.FileName
            pbFoto.Image = Image.FromFile(pathFoto)
            pbFoto.SizeMode = PictureBoxSizeMode.StretchImage
        End If
    End Sub

    Private Sub cmbUsername_LostFocus(sender As Object, e As EventArgs) Handles cmbUsername.LostFocus
        If cmbUsername.Text = "" Then Exit Sub

        Try
            koneksi()
            Dim query As String = "SELECT * FROM tbl_user WHERE username = ?"
            cmd = New OdbcCommand(query, conn)
            cmd.Parameters.AddWithValue("@1", cmbUsername.Text)
            rd = cmd.ExecuteReader()

            If rd.Read() Then
                txtPassword.Text = rd("password").ToString
                cmbStatus.Text = rd("status_user").ToString
                pathFoto = rd("foto_user").ToString
                If System.IO.File.Exists(pathFoto) Then
                    pbFoto.Image = Image.FromFile(pathFoto)
                    pbFoto.SizeMode = PictureBoxSizeMode.StretchImage
                Else
                    pbFoto.Image = Nothing
                End If
            Else
                txtPassword.Clear()
                cmbStatus.SelectedIndex = -1
                pbFoto.Image = Nothing
                pathFoto = ""
            End If
        Catch ex As Exception
            MsgBox("Gagal Cek Username: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub

    Private Sub FormUser_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        tampilData()
        cmbStatus.Items.Clear()
        cmbStatus.Items.AddRange(New String() {"Administrator", "Operator"})
        isiUsername()
    End Sub

    Private Sub dgvUser_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvUser.CellClick
        Try
            Dim row As DataGridViewRow = dgvUser.CurrentRow
            cmbUsername.Text = row.Cells("username").Value.ToString()
            txtPassword.Text = row.Cells("password").Value.ToString()
            cmbStatus.Text = row.Cells("status_user").Value.ToString()
            pathFoto = row.Cells("foto_user").Value.ToString()
            If System.IO.File.Exists(pathFoto) Then
                pbFoto.Image = Image.FromFile(pathFoto)
                pbFoto.SizeMode = PictureBoxSizeMode.StretchImage
            Else
                pbFoto.Image = Nothing
            End If
        Catch ex As Exception
            pbFoto.Image = Nothing
        End Try
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnPilihFoto.Click

    End Sub
End Class